/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataBase;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author ktkun
 */
public class DBConnection {
    private String driver="com.mysql.cj.jdbc.Driver",url="jdbc:mysql://localhost:3306/qlgiangvien",user="root",pass="";
    private final Logger l = Logger.getLogger(DBConnection.class.getName());
    private Connection con = null;
    public DBConnection(){
        try{
            Class.forName(driver);
        }catch(ClassNotFoundException ex){
            l.log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection Connect(){
        try{
            this.con=DriverManager.getConnection(url, user, pass);
            return con;
        }catch(SQLException ex){
            l.log(Level.SEVERE, null, ex);
            if(con != null){
                try{
                    con.close();
                }catch(SQLException e){
                    l.log(Level.SEVERE, null, e);
                }
            }
            return null;
        }
    }
    
    public void Disconnect(){
             if(con != null){
                try{
                    con.close();
                }catch(SQLException e){
                    l.log(Level.SEVERE, null, e);
                }
            }       
    }
    
    public ResultSet GetData(String sql){
        ResultSet rs = null;
        try{
            if(con != null && !con.isClosed()){
                Statement st = con.createStatement();
                rs=st.executeQuery(sql);
            }
        }catch(SQLException ex){
            l.log(Level.SEVERE, sql, ex);
            return null;
        }
        return rs;
    }
    
    public int Query(String sql){
        int kq = -1;
        try{
            if(con != null && !con.isClosed()){
                Statement st = con.createStatement();
                kq=st.executeUpdate(sql);
            }
        }catch(SQLException ex){
            l.log(Level.SEVERE, null, ex);
        }
        return kq;
    }
}
