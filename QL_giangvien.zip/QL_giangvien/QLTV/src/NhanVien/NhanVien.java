/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NhanVien;

import java.util.Scanner;

/**
 *
 * @author ktkun
 */
public class NhanVien {
    private String manv, hoten,que;
    private float hsl;

    public String getManv() {
        return manv;
    }

    public void setManv(String manv) {
        this.manv = manv;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public String getQue() {
        return que;
    }

    public void setQue(String que) {
        this.que = que;
    }

    public float getHsl() {
        return hsl;
    }

    public void setHsl(float hsl) {
        this.hsl = hsl;
    }
    public NhanVien() {
        this.manv = "";
        this.hoten = "";
        this.que = "";
        this.hsl = 0;
    }
    public NhanVien(String manv, String hoten, String que, float hsl) {
        this.manv = manv;
        this.hoten = hoten;
        this.que = que;
        this.hsl = hsl;
    }

    @Override
    public String toString() {
        return "NhanVien{" + "manv=" + manv + ", hoten=" + hoten + ", que=" + que + ", hsl=" + hsl + '}';
    }
    public void hienthi(){
        System.out.println(toString());
    }
    public void nhap(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap Ma NV: ");
        manv=sc.next();
        System.out.print("Nhap Ho Ten: ");
        hoten=sc.next();
        sc.nextLine();
        System.out.print("Nhap Que: ");
        que=sc.next();
        System.out.print("Nhap HSL: ");
        hsl=sc.nextInt();
    }
 }
