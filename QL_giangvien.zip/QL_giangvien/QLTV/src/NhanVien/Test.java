/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NhanVien;

import java.util.Scanner;

/**
 *
 * @author ktkun
 */
public class Test {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);            
        int n;
        System.out.println("Nhap n=");
        n=sc.nextInt();
        
        NhanVien[] a = new NhanVien[n]; 
        for(int i=0;i<n;i++){
            a[i]=new NhanVien();
            a[i].nhap();
            System.out.println();
        }
        for(int i=0;i<n;i++){
            a[i].hienthi();
        }
        String tk;
        System.out.print("Nhap ten nv can tim kiem: ");
        tk=sc.next();
        for(int i=0;i<n;i++){
            if(a[i].getHoten().equalsIgnoreCase(tk)){
                a[i].hienthi();
                break;
            }
        }
    }
}
