/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Process;
import DataBase.DBConnection;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
/**
 *
 * @author ktkun
 */

public class DataBaseManager {
    private static final Logger l = Logger.getLogger(DBConnection.class.getName());
    private static String sql;
    
    public static ResultSet GetData(String sql){
        DBConnection db = new DBConnection();
        db.Connect();
        return db.GetData(sql);        
    }
    
     public static void Query(String sql){
        DBConnection db = new DBConnection();
        db.Connect();
        db.Query(sql); 
        db.Disconnect();
    }   
     
     public static boolean Table(JTable j){
         DBConnection db = new DBConnection();
         ResultSet rs = null;
             rs = GetData("Select * from tt_gvien");
             if(rs==null)
                 return false;
             try{
                 DefaultTableModel dtm = (DefaultTableModel)j.getModel();
                 dtm.setRowCount(0);
                 
                 ResultSetMetaData rd = rs.getMetaData();
                 int end = rd.getColumnCount();
                 while(rs.next()){
                     Object[] o = new Object[end];
                     for(int i=0;i<end;i++){
                         o[i] = rs.getString(i+1);
                     }
                     dtm.addRow(o);
                 }
                 return true;
             }catch(SQLException e){
                 l.log(Level.SEVERE, null, e);
                 return false;
             }finally{
                     db.Disconnect();        
             }
     }
     public static boolean kt(String ma){
         ResultSet rs;    
         try{
                rs=GetData("select * from tt_gvien where magv='"+ma+"'");
                return rs.next();
         }catch(SQLException ex){
             l.log(Level.SEVERE, null, ex);
             return false;
         }

     }
     public static void them(String ma, String ten, String dc, int hsl){
         if(!kt(ma))
         {
             sql="insert into tt_gvien values('"+ma+"',N'"+ten+"',N'"+dc+"','"+hsl+"')";
             Query(sql);
         }
         else{
             JOptionPane.showMessageDialog(null,"Mã giảng viên đã tồn tại","Thong bao",JOptionPane.WARNING_MESSAGE);
         }
     }
     public static void sua(String ma, String ten, String dc, int hsl){
         sql="update tt_gvien set tengv=N'"+ten+"', dchi=N'"+dc+"',hsluong='"+hsl+"' where magv='"+ma+"'";
         Query(sql);
     }
     public static void xoa(String ma){
         sql="delete tt_gvien where magv='"+ma+"'";
         Query(sql);
     }
     public static ResultSet search(String ten){
         return GetData("select * from tt_gvien where tengv like N'"+ten+"'");
     }
}


