/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ktkun
 */
public class DB {

    Connection con = null;
    String driver = "com.mysql.cj.jdbc.Driver", url = "jdbc:mysql://localhost:3306/QLhocvien", user = "root", pass = "";
    Logger j = Logger.getLogger(DB.class.getName());

    public DB() {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException ex) {
            j.log(Level.SEVERE, null, ex);
        }
    }

    public Connection ketnoi() {
        try {
            this.con = DriverManager.getConnection(url, user, pass);
            return con;
        } catch (SQLException ex) {
            j.log(Level.SEVERE, null, ex);
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    j.log(Level.SEVERE, null, ex);
                }
            }
            return null;
        }
    }

    public void huyketnoi() {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                j.log(Level.SEVERE, null, e);
            }
        }
    }
    
    public ResultSet GetData(String sql){
        ResultSet rs = null;
        Statement st;
        try{
            st = con.createStatement();
            rs = st.executeQuery(sql);
        }catch(SQLException ex){
            j.log(Level.SEVERE, null, ex);
        }
        return rs;
    }
    
    public int Update(String sql) {
        int kq = -1;
        Statement st;
        try {
            st = con.createStatement();
            kq = st.executeUpdate(sql);
        } catch (SQLException ex) {
            j.log(Level.SEVERE, null, ex);
        }
        return kq;
    }
        
    public boolean hienthi(JTable j,String sql){
        ketnoi();
        ResultSet rs = GetData(sql);
        if(rs == null)
            return false;
        try{
            DefaultTableModel dtm = (DefaultTableModel)j.getModel();
            dtm.setRowCount(0);
            
            ResultSetMetaData rd = rs.getMetaData();
            int end = rd.getColumnCount();
            
            while(rs.next()){
                Object[] o = new Object[end];
                for(int i=0; i<end; i++){
                    o[i] = rs.getString(i+1);
                }
                dtm.addRow(o);
            }
            return true;
        }catch(SQLException ex){
           JOptionPane.showMessageDialog(null, "Khong co du lieu","Thong bao",JOptionPane.ERROR_MESSAGE);
        }finally{
            huyketnoi();
        }
        return false;
    }  
}
