
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author ktkun
 */
public class SinhVien {

    private String maSv, tenSv, lopSv;
    private Date ngaySinh;
    private float diemtb;

    public SinhVien() {
        this.maSv = "";
        this.tenSv = "";
        this.lopSv = "";
        this.ngaySinh = null;
        this.diemtb = 0;
    }

    public SinhVien(String maSv, String tenSv, String lopSv, Date ngaySinh, float diemtb) {
        this.maSv = maSv;
        this.tenSv = tenSv;
        this.lopSv = lopSv;
        this.ngaySinh = ngaySinh;
        this.diemtb = diemtb;
    }

    public String getMaSv() {
        return maSv;
    }

    public void setMaSv(String maSv) {
        this.maSv = maSv;
    }

    public String getTenSv() {
        return tenSv;
    }

    public void setTenSv(String tenSv) {
        this.tenSv = tenSv;
    }

    public String getLopSv() {
        return lopSv;
    }

    public void setLopSv(String lopSv) {
        this.lopSv = lopSv;
    }

    public Date getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(Date ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public float getDiemtb() {
        return diemtb;
    }

    public void setDiemtb(float diemtb) {
        this.diemtb = diemtb;
    }

    public void nhap() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Nhap ma SV: ");
        maSv = sc.nextLine();
        System.out.print("Nhap ten SV: ");
        tenSv = sc.nextLine();

        SimpleDateFormat d = new SimpleDateFormat("dd MM yyyy");
        System.out.print("Nhap ngay sinh SV theo dinh dang(dd MM yyyy): ");
        try {
            ngaySinh = d.parse(sc.nextLine());
        } catch (Exception ex) {
            System.out.print("Ban nhap sai dinh dang ");
        }
        System.out.print("Nhap lop SV: ");
        lopSv = sc.nextLine();
        System.out.print("Nhap diem tb SV: ");
        diemtb = sc.nextFloat();
    }
    public void xuat(){
        SimpleDateFormat d = new SimpleDateFormat("dd MM yyyy");
        System.out.println("Ma SV: "+maSv+" Ten SV: "+tenSv+" Ngay Sinh: "+d.format(ngaySinh)+ " Lop: "+lopSv+" Diem TB: "+diemtb);
    }
    
}
