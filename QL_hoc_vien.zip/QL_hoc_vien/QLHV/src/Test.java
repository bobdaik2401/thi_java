
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author ktkun
 */
public class Test {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.print("Nhap so luong sv: ");
        n = sc.nextInt();
        SinhVien[] arr = new SinhVien[n];

        for (int i = 0; i < n; i++) {
            arr[i] = new SinhVien();
            arr[i].nhap();
        }

        for (int i = 0; i < n; i++) {
            arr[i].xuat();
        }
        try {
            SimpleDateFormat d = new SimpleDateFormat("dd MM yyyy");
            Date a = d.parse("01 01 2020");
            Date b = d.parse("31 01 2020");
            for(int i=0; i<n; i++){
                Date ns = arr[i].getNgaySinh();
                if(!ns.before(a) && !ns.after(b)){
                    arr[i].xuat();
                }
            }
        }catch(Exception ex){
            
        }
    }
}
