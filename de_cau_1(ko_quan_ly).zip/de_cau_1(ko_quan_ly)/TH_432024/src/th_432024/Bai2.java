/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package th_432024;
import java.util.Scanner;
/**
 *
 * @author ktkun
 */
public class Bai2 {
    public static void main(String[] args) {
        Double a,b,c,x1,x2;
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap a= ");
        a=sc.nextDouble();
        System.out.println("Nhap b= ");
        b=sc.nextDouble();
        System.out.println("Nhap c= ");
        c=sc.nextDouble();
        Double dt = (b*b)-4*a*c;
        if(dt > 0){
            x1= (-b + Math.sqrt(dt))/(2*a);
            x2= (-b - Math.sqrt(dt))/(2*a);
            System.out.println("X1= " + x1+ " X2= "+x2);
        }else if( dt == 0){
            double x=-b/(2*a);
            System.out.println("X= "+x);
        }else{
            System.out.print("PT vo nghiem");
        }
        
    }
}
