/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package th_432024;
import java.util.Scanner;
/**
 *
 * @author ktkun
 */
public class Bai3 {
    public static void menu(){
        System.out.println("+=============================MENU========================+");
        System.out.println("+            1.Nhập n                                     +");
        System.out.println("+            2.Tong 1->n                                  +");
        System.out.println("+            3.KT so NT                                   +");
        System.out.println("+            4.KT so HH                                   +");
        System.out.println("+            5.Xuat so n thành tích các thừa số nguyên tố.+");
        System.out.println("+            6.Thoat                                      +");
        System.out.println("+=========================================================+"); 
    }
    public static void nhap(int a[],int n){
        Scanner s= new Scanner(System.in);
        for(int i=1;i<n;i++){
            System.out.print("Nhap so thu "+i+": ");
            a[i]=s.nextInt();
        }
    }
    public static int tong(int a[],int n){
        int s=0;
        for(int i=1;i<n;i++){
            s+=a[i];
        }
        return s;
    }
    public static boolean KTsnt(int n){
        if(n<2)
            return true;
        else{
            for(int i=2;i<=Math.sqrt(n);i++){
                if(n%i==0)
                    return false;
            }
        }
        return true;
        
    }
    public static void xuatsoNT(int a[], int n){
        System.out.println("Cac so NT la: ");
        for(int i=1;i<n;i++){
            if(KTsnt(a[i])){
                System.out.print(a[i]+" ");
            }
        }
    }
    public static boolean KTshh(int n){
        int s=0;
        for(int i=1;i<n;i++){
            if(n%i==0){
                s+=i;
            }
        }
        if(s==n)
            return true;
        else 
            return false;
    }
     public static void xuatsoHH(int a[], int n){
        System.out.println("Cac so HH la: ");
        for(int i=1;i<n;i++){
            if(KTshh(a[i])){
                System.out.print(a[i]+" ");
            }
        }
    } 
     public static void PTTSNT(int n){
         int i=2;
         System.out.print("Tich thua so cua "+n+": ");
       while (n != 1) {
            int count = 0;
            while (n % i == 0) {
                n /= i;
                count++;
            }
            if (count > 0) {
                if (count == 1) {
                    System.out.print(i);
                } else {
                    System.out.print(i + "^" + count);
                }
                if (n != 1) {
                    System.out.print(" * ");
                }
            }
            i++;
        }
         System.out.println();
     }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.print("Nhap n= ");
        n=sc.nextInt();
        int[] a= new int[n];
        char chon;
        do{
            menu();
            System.out.print("Nhap lua chon cua ban: ");
            chon=sc.next().charAt(0);
            switch(chon){
                case '1':
                        nhap(a,n);break;
                case '2':
                        System.out.println("Tong 1->n = " +tong(a,n));
                        break;
                case '3':
                        xuatsoNT(a,n); break;
                case '4':
                        xuatsoHH(a,n);break;
                case '5':
                        PTTSNT(n);break;
                case '6':
                    System.exit(0);break;
                default:
                    System.out.println("Sai dinh dang !!!");
            }
            System.out.print("Ban co muon tiep tuc?(y/n): ");
            chon=sc.next().charAt(0);
        }while(chon != 'n');
    }
}
