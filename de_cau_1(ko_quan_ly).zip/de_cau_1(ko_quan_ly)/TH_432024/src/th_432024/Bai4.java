/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package th_432024;
import java.util.Scanner;
/**
 *
 * @author ktkun
 */
public class Bai4 {
    public static int UCLN(int a, int b){
        while(a!=b){
            if(a>b)
                a-=b;
            else
                b-=a;
        }
        return a;
    }
    public static int BCNN(int a, int b){
        return (a*b)/UCLN(a,b);
    }
    public static void main(String[] args){
        int a,b;
        Scanner sc= new Scanner(System.in);
        System.out.print("Nhap số nguyên a: ");
        a=sc.nextInt();
        System.out.print("Nhap số nguyên b: ");
        b=sc.nextInt(); 
        System.out.println("UCLN cua "+a+" va "+b+" la: "+UCLN(a,b));
        System.out.println("BCNN cua "+a+" va "+b+" la: "+BCNN(a,b));
    }
}
