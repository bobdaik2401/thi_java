/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package th_432024;
import java.util.Scanner;
/**
 *
 * @author ktkun
 */
public class Bai5 {
    public static void nhap(int a[], int n){
        Scanner s= new Scanner(System.in);
        for(int i=0;i<n;i++){
            System.out.print("Nhap so thu "+(i+1)+": ");
            a[i]=s.nextInt();
        }
    }
    public static void xuat(int a[], int n){
        for(int i=0;i<n;i++){
            System.out.print(a[i] + " ");          
        }
    }
    public static void xoa(int a[], int n, int x){
        int k=0, vt=0;
        for(int i=0;i<n;i++){
            if(a[i]==x){
                k=1;
                vt=i;
                break;
            }
            else{
                k=0;
            }
                    
        }
        if(k ==1){
            for(int i=vt+1;i<n;i++){
                a[i-1]=a[i];
            }
            System.out.print("Mang sau khi xoa la: ");
            for (int i = 0; i < n-2; i++){
            System.out.print(a[i]+" ");
            }
            System.out.print(a[n-2]);
        }else{
            System.out.print("Không tìm thấy số cần xóa ");
        }
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n,x;
        System.out.print("Nhap n= ");
        n=sc.nextInt();
        int[] a= new int[n];
        nhap(a,n);
        System.out.print("Nhap so ma ban muon xoa: ");
        x=sc.nextInt();
        xoa(a,n,x);
    }
}
