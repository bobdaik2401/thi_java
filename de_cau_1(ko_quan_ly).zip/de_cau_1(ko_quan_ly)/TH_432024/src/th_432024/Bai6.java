/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package th_432024;

import java.util.Scanner;

/**
 *
 * @author ktkun
 */
public class Bai6 {
      public static void nhap(int a[], int n){
        Scanner s= new Scanner(System.in);
        for(int i=0;i<n;i++){
            System.out.print("Nhap so thu "+(i+1)+": ");
            a[i]=s.nextInt();
        }
    }
    public static void xuat(int a[], int n){
        System.out.println("Xuat mang: ");
        for(int i=0;i<n;i++){
            System.out.print(a[i] + " ");          
        }
        System.out.println();
    }  
    public static void sort(int a[], int n){
        for(int i = 1; i < n; i++){
            int value = a[i];
            int j = i - 1;          
                while(j >= 0 && a[j] > value){
                    a[j + 1] = a[j];
                    j = j - 1;
                }
            a[j + 1] = value;
        }
    }
    public static int min(int a[], int n){
        int Min =0;
            for(int i=1;i<n;i++){
                if(a[Min]>a[i]){
                    Min=i;
                }
            }
            return Min;
    }
    public static void tbc(int a[], int n){
        int s=0,dem=0;
        for(int i=0;i<n;i++){
            if(a[i]%3==0){
                s+=a[i];
                dem++;
            }
        }
        float tbc=(float) s/dem;
        System.out.println("Trung binh cong chia het cho 3 la: "+tbc);
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n,x;
        System.out.print("Nhap n= ");
        n=sc.nextInt();
        int[] a= new int[n];
        nhap(a,n); 
        sort(a,n);
        xuat(a,n);
        System.out.println("Phan tu co gia tri nho nhat la: "+min(a,n));
        tbc(a,n);
    }
}
