/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cau1;

import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author ktkun
 */
public class KHNuocNgoai extends KhachHang{
    private String qt;

    public KHNuocNgoai() {
        this.qt = "";
    }

    public KHNuocNgoai(String qt, String makh, String hoten, Date ngayXuathd, int sl, int dg) {
        super(makh, hoten, ngayXuathd, sl, dg);
        this.qt = qt;
    }

    public String getQt() {
        return qt;
    }

    public void setQt(String qt) {
        this.qt = qt;
    }
    public void nhap(){
        super.nhap();
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap quoc tich: ");
        qt = sc.nextLine();
    }

    public double tt(){
        return super.getSl()*super.getDg();
    }

    @Override
    public String toString() {
       
        return  super.toString()+"qt=" + qt+"Thanh tien="+tt();
    }

}
