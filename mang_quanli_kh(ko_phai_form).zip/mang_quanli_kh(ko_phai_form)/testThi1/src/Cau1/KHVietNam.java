/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cau1;

import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author ktkun
 */
public class KHVietNam extends KhachHang {

    private String dt;
    private int dm;

    public KHVietNam() {
        this.dt = "";
        this.dm = 0;
    }

    public KHVietNam(String dt, int dm, String makh, String hoten, Date ngayXuathd, int sl, int dg) {
        super(makh, hoten, ngayXuathd, sl, dg);
        this.dt = dt;
        this.dm = dm;
    }

    public String getDt() {
        return dt;
    }

    public void setDt(String dt) {
        this.dt = dt;
    }

    public int getDm() {
        return dm;
    }

    public void setDm(int dm) {
        this.dm = dm;
    }

    public void nhap() {
        super.nhap();
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap doi tuong(Sinh Hoat |  Kinh Doanh | San Xuat): ");
        dt = sc.nextLine();
        System.out.print("Nhap dinh muc: ");
        dm = sc.nextInt();
    }

    public double tt() {
        double tt = 0;
        if (super.getSl() <= dm) {
            tt = super.getSl() * super.getDg();
        } else {
            tt = super.getSl() * super.getDg() * dm + ((super.getSl() - dm)) * super.getDg() * 2.5;
        }
        return tt;
    }

    @Override
    public String toString() {
        return super.toString() + "" + "doiTuong='" + dt + ", dinhMuc=" + dm + "Thanh Tien" + tt();
    }

}
