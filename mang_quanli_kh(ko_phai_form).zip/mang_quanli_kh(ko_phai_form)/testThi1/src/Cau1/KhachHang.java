/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cau1;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author ktkun
 */
public abstract class KhachHang {

    private String makh, hoten;
    private Date ngayXuathd;
    private int sl, dg;

    public KhachHang() {
        this.makh = "";
        this.hoten = "";
        this.ngayXuathd = null;
        this.sl = 0;
        this.dg = 0;
    }

    public KhachHang(String makh, String hoten, Date ngayXuathd, int sl, int dg) {
        this.makh = makh;
        this.hoten = hoten;
        this.ngayXuathd = ngayXuathd;
        this.sl = sl;
        this.dg = dg;
    }

    public String getMakh() {
        return makh;
    }

    public void setMakh(String makh) {
        this.makh = makh;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public Date getNgayXuathd() {
        return ngayXuathd;
    }

    public void setNgayXuathd(Date ngayXuathd) {
        this.ngayXuathd = ngayXuathd;
    }

    public int getSl() {
        return sl;
    }

    public void setSl(int sl) {
        this.sl = sl;
    }

    public int getDg() {
        return dg;
    }

    public void setDg(int dg) {
        this.dg = dg;
    }

    public void nhap() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap Ma kh: ");
        makh = sc.nextLine();
        System.out.print("Nhap Ten kh: ");
        hoten = sc.nextLine();
        System.out.print("Nhap Ngay Xuat HD: ");
        SimpleDateFormat s = new SimpleDateFormat("dd MM yyyy");
        try {
            ngayXuathd = s.parse(sc.nextLine());
        } catch (Exception ex) {
            System.out.print("Nhap sai dinh dang! \n Vui long nhap theo (dd MM yyyy)");
            try {
                ngayXuathd= s.parse(sc.nextLine());
            } catch (Exception e) {

            }
        }
        System.out.print("Nhap Số lượng: ");
        sl = sc.nextInt();
        System.out.print("Nhap Đơn Giá: ");
        dg = sc.nextInt();
    }

    @Override
    public String toString() {
        SimpleDateFormat s = new SimpleDateFormat("dd MM yyyy");
        return "KhachHang" + "makh=" + makh + ", hoten=" + hoten + ", ngayXuathd=" + s.format(ngayXuathd) + ", sl=" + sl + ", dg=" + dg ;
    }

    public abstract double tt();
}
