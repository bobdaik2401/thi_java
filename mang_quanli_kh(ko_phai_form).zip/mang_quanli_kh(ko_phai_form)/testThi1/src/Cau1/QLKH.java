/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cau1;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author ktkun
 */
public class QLKH {

    public static void main(String[] args) {
        ArrayList<KhachHang> kh = new ArrayList<>();

        Scanner sc = new Scanner(System.in);
        int lc1;
        do {

            System.out.println("+========MENU==========+");
            System.out.println("+     1.Nhap           +");
            System.out.println("+     2.Xuat           +");
            System.out.println("+     3.In HD          +");
            System.out.println("+     4.Exit           +");
            System.out.println("+======================+");
            System.out.print("Nhap lua chon cau ban: ");
            lc1 = sc.nextInt();

            switch (lc1) {
                case 1:
                    boolean kt = true;
                    while (kt) {
                        int lc;
                        System.out.println("+========Chon Nhap==========+");
                        System.out.println("+     1.KH Viet Nam    +");
                        System.out.println("+     2.KH Nguoc Ngoai +");
                        System.out.println("+     3.Thoat          +");
                        System.out.println("+======================+");
                        System.out.print("Nhap lua chon cau ban: ");
                        lc = sc.nextInt();
                        switch (lc) {
                            case 1:
                                KHVietNam a = new KHVietNam();

                                a.nhap();
                                kh.add(a);
                                break;
                            case 2:

                                KHNuocNgoai b = new KHNuocNgoai();
                                b.nhap();
                                kh.add(b);
                                break;
                            case 3:
                                kt = false;
                                break;
                            default:
                                System.out.println("Lua chon khong hop le. Vui long chon lai.");
                                break;
                        }

                    }
                    break;
                case 2:
                    System.out.println("Thong tin tat ca cac KH la: ");
                    for (KhachHang item : kh) {
                        System.out.println(item.toString());
                    }
                    break;
                case 3:
                    try {
                        SimpleDateFormat f = new SimpleDateFormat("dd MM yyyy");
                        Date a = f.parse("01 08 2022");
                        Date b = f.parse("31 08 2022");
                        System.out.println("Hd thang 8 nam 2022:" );
                        for(KhachHang item:kh){
                            Date d = item.getNgayXuathd();
                            if(!d.before(a) && !d.after(b)){
                                System.out.println(item.toString());
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("Loi");
            }
            System.out.print("Ban co muon tiep tuc(1/0): ");
            lc1 = sc.nextInt();
        } while (lc1 != 0);
    }
}
