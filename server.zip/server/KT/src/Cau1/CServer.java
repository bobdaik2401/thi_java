package Cau1;

import javax.swing.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CServer extends Thread {
    private ServerSocket mServer;
    private JTextArea mTxaStatus; // JTextArea để lưu status của Server
    private Map<String, String> dictionary; // Từ điển
    private volatile boolean running = true; // Biến để kiểm soát trạng thái chạy của server

    public CServer(JTextArea txaStatus) {
        mTxaStatus = txaStatus;
        dictionary = loadDictionary("Dictionary.txt");
    }

    private Map<String, String> loadDictionary(String filePath) {
        Map<String, String> dict = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("=");
                if (parts.length == 2) {
                    dict.put(parts[0].trim().toLowerCase(), parts[1].trim());
                }
            }
        } catch (IOException e) {
            Logger.getLogger(CServer.class.getName()).log(Level.SEVERE, null, e);
        }
        return dict;
    }

    @Override
    public void run() {
        try {
            mServer = new ServerSocket(2520);
            mTxaStatus.append("Server đã sẵn sàng!\nĐang chờ dữ liệu...\n\n");

            while (running) {
                try {
                    Socket connectionSocket = mServer.accept();
                    DataInputStream inFromClient = new DataInputStream(connectionSocket.getInputStream());
                    DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());

                    String word = inFromClient.readLine().trim().toLowerCase();
                    mTxaStatus.append("Đã nhận từ cần tra: " + word + "\n");

                    String result = dictionary.getOrDefault(word, "null");
                    mTxaStatus.append("Kết quả tra từ: " + result + "\n");

                    outToClient.writeBytes(result + '\n');
                    mTxaStatus.append("Đã gửi kết quả về cho Client thành công\n\n");
                } catch (IOException e) {
                    if (running) {
                        Logger.getLogger(CServer.class.getName()).log(Level.SEVERE, null, e);
                        mTxaStatus.append("Server đã xảy ra lỗi\n");
                    }
                }
            }
        } catch (SocketException e) {
            if (!running) {
                mTxaStatus.append("Server đã dừng.\n");
            } else {
                Logger.getLogger(CServer.class.getName()).log(Level.SEVERE, null, e);
                mTxaStatus.append("Server đã xảy ra lỗi\n");
            }
        } catch (IOException ex) {
            Logger.getLogger(CServer.class.getName()).log(Level.SEVERE, null, ex);
            mTxaStatus.append("Server đã xảy ra lỗi\n");
        } finally {
            try {
                if (mServer != null && !mServer.isClosed()) {
                    mServer.close();
                }
            } catch (IOException e) {
                Logger.getLogger(CServer.class.getName()).log(Level.SEVERE, null, e);
            }
        }
    }

    public void StopServer() {
        running = false;
        try {
            if (mServer != null) {
                mServer.close();
            }
        } catch (IOException ex) {
            Logger.getLogger(CServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
