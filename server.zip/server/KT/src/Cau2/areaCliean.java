/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cau2;

/**
 *
 * @author Admin
 */
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class areaCliean {

    public static void main(String[] args) {
        String serverName = "localhost"; // Địa chỉ server
        int port = 3456; // Cổng server

        try {
            // Gửi kết nối tới Server
            Socket client = new Socket(serverName, port);
            System.out.println("Đã kết nối đến " + client.getRemoteSocketAddress());

            // Tạo luồng gửi dữ liệu lên server
            DataOutputStream outToServer = new DataOutputStream(client.getOutputStream());
            // Tạo luồng nhận dữ liệu từ server
            DataInputStream inFromServer = new DataInputStream(client.getInputStream());

            // Nhập ba số nguyên từ bàn phím
            Scanner scanner = new Scanner(System.in);
            System.out.print("Nhập ba số nguyên: ");
            int side1 = scanner.nextInt();
            int side2 = scanner.nextInt();
            int side3 = scanner.nextInt();

            // Gửi ba số nguyên đến server
            outToServer.writeInt(side1);
            outToServer.writeInt(side2);
            outToServer.writeInt(side3);

            // Nhận kết quả từ server
            String triangleType = inFromServer.readUTF();
            System.out.println("Loại tam giác: " + triangleType);

            // Đóng kết nối
            client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
