/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cau2;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.atomic.AtomicInteger;

public class areaServer {

    private static AtomicInteger threadCounter = new AtomicInteger(0);

    public static void main(String[] args) {
        ServerSocket serverSocket = null;
        try {
            // Khởi tạo đối tượng ServerSocket và nghe tại số cổng 3456
            serverSocket = new ServerSocket(3456);
            System.out.println("Server đang chạy...");

            // Thực hiện lặp lại các công việc
            while (true) {
                // Nhận kết nối mới, tạo socket mới
                Socket clientSocket = serverSocket.accept();
                int threadNumber = threadCounter.incrementAndGet();

                // Phát sinh một luồng mới và nhận socket
                Thread thread = new ClientHandler(clientSocket, threadNumber);
                thread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (serverSocket != null) {
                    serverSocket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

class ClientHandler extends Thread {
    private Socket clientSocket;
    private int threadNumber;

    public ClientHandler(Socket socket, int threadNumber) {
        this.clientSocket = socket;
        this.threadNumber = threadNumber;
    }

    @Override
    public void run() {
        try {
            // Tạo luồng vào và ra cho client
            DataInputStream inputStream = new DataInputStream(clientSocket.getInputStream());
            DataOutputStream outputStream = new DataOutputStream(clientSocket.getOutputStream());

            // Nhận ba số từ Client
            int side1 = inputStream.readInt();
            int side2 = inputStream.readInt();
            int side3 = inputStream.readInt();

            // Kiểm tra tam giác và xác định loại tam giác
            String triangleType = getTriangleType(side1, side2, side3);

            // Hiển thị thông tin về client
            System.out.println("Thread #" + threadNumber);
            System.out.println("Client IP: " + clientSocket.getInetAddress());
            System.out.println("Client Port: " + clientSocket.getPort());
            System.out.println("Ba số nhận từ client: " + side1 + ", " + side2 + ", " + side3);
            System.out.println("Loại tam giác: " + triangleType);
            System.out.println();

            // Gửi loại tam giác về cho Client
            outputStream.writeUTF(triangleType);

            // Đóng kết nối
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getTriangleType(int side1, int side2, int side3) {
        if (side1 <= 0 || side2 <= 0 || side3 <= 0)
            return "Không phải tam giác";
        if (side1 == side2 && side2 == side3)
            return "Tam giác đều";
        if (side1 == side2 || side1 == side3 || side2 == side3)
            return "Tam giác cân";
        if (Math.pow(side1, 2) == Math.pow(side2, 2) + Math.pow(side3, 2) ||
                Math.pow(side2, 2) == Math.pow(side1, 2) + Math.pow(side3, 2) ||
                Math.pow(side3, 2) == Math.pow(side1, 2) + Math.pow(side2, 2))
            return "Tam giác vuông";
        return "Tam giác thường";
    }
}
